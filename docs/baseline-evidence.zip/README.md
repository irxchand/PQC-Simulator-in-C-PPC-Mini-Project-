# DOC-04 baseline evidence

This bundle verifies the unchanged upstream source at commit
`eff9baaea6a08c22cd317449a18b89894ef020dd`.
It contains verification code, generated probes, fixtures, raw output, and
`results.json`. It contains no upstream source copy and no project extension.

## Reproduce

Use Linux with GCC, Python 3, Git, libm, and GCC address/undefined sanitizers:

```bash
git clone https://github.com/irxchand/PQC-Simulator-in-C-PPC-Mini-Project-.git upstream
git -C upstream checkout eff9baaea6a08c22cd317449a18b89894ef020dd
python3 verify_baseline.py "$PWD/upstream"
```

The script writes build/probe binaries and regenerated files beside itself,
not inside the source repository. Each command has a 30-second verification
timeout, not a product performance target. The source working tree must be
clean. The ordinary build follows the repository README; the additional build
uses C11, `-Wall -Wextra -Wpedantic`.

## Interpretation

- 77 complex statevector comparisons cover single-qubit gates at both two-qubit
  positions, multiple rotation angles, every three-qubit CX control/target
  ordering on all basis states, and a Bell state. The Python reference applies
  mathematical operator elements independently of the C pair-update loops.
- Four initial PQC predictions are independently checked using those operators.
- CLI cases exercise menu exit, interactive Bell preparation, the supplied
  file, training in fresh processes, training twice in one process, malformed
  legacy file behavior, and the four-qubit example specified in DOC-04.
- The probe includes unchanged `a.c` with its menu entry point renamed at
  preprocessing time, then calls the original gate, parser, forward, and
  training functions. It does not implement a replacement training loop.
- `srand(1)` in the verification probe recreates the initial default RNG state
  used by a fresh process on this glibc environment. The actual upstream menu
  does not call `srand`. Results are not a portable RNG guarantee.
- Encoding/readout-only is an ablation, not the full PQC at zero parameters.
  Full-PQC zero-parameter predictions are separately included in `results.json`.
- Final menu predictions have four decimal places. The final MSE computed in
  `results.json` is explicitly based on these rounded predictions. Epoch 200
  prints loss before its parameter update, not the exact post-update loss.
- The parser probes record invalid behavior; accepting trailing tokens or
  nonfinite angles is not an acceptance requirement for the extension.
- `sanitizer.stderr` records the first default LeakSanitizer run failing because
  this hosted runtime restricts process inspection. The reproducible script
  disables only leak detection and retains ASan/UBSan. The latter run exits
  successfully with empty diagnostics (`sanitizer-no-leaks.stderr`). Leak
  freedom is not established by this run.

The four-qubit fixture executes eight logical gates and contains ordered CX
operations `(0,1), (0,3), (2,3)`. It is a fixed parameter setting of a small
parameterized circuit family, not an additional trained classifier. No Graph,
BFS, estimator, shared-loader refactor, or new CLI has been implemented.

The evidence is bounded to these cases and this environment. It is not a proof
of correctness for all circuits, hardware performance, or generalization.
