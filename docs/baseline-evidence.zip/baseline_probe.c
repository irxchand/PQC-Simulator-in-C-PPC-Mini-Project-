
#define main upstream_menu_main
#include "a.c"
#undef main
static void emit(const char *name, struct st *s) {
    printf("STATE %s", name);
    for (int i=0;i<s->sz;i++) printf(" %.17g %.17g",s->arr[i].r,s->arr[i].i);
    printf("\n"); free_st(s);
}
int main(void) {
    const double angles[]={0, PI/2, PI, -PI/3};
    for(int type=0;type<5;type++) for(int q=0;q<2;q++) {
        int count=(type<2)?1:4;
        for(int a=0;a<count;a++) {
            struct st *s=make_st(2);
            struct gt h0={1,0,-1,0},r1={3,1,-1,0.7},z0={4,0,-1,0.4};
            app_gt(s,h0,0);app_gt(s,r1,0);app_gt(s,z0,0);
            struct gt g={type,q,-1,angles[a]};app_gt(s,g,0);
            char label[80];snprintf(label,sizeof(label),"gate_%d_%d_%d",type,q,a);
            emit(label,s);
        }
    }
    for(int c=0;c<3;c++)for(int t=0;t<3;t++)if(c!=t)for(int b=0;b<8;b++) {
        struct st *s=make_st(3);s->arr[0].r=0;s->arr[b].r=1;
        struct gt g={5,t,c,0};app_gt(s,g,0);
        char label[80];snprintf(label,sizeof(label),"cx_%d_%d_%d",c,t,b);emit(label,s);
    }
    struct st *bell=make_st(2);struct gt h={1,0,-1,0},cx={5,1,0,0};
    app_gt(bell,h,0);app_gt(bell,cx,0);emit("bell",bell);
    char *bad[]={"CX 0 1 extra","X 0 extra","RY 0 nan","RY 0 inf","H 0.5","CX 0 0","BOGUS 0"};
    for(int i=0;i<7;i++){struct gt g={0};int p=get_gt(bad[i],&g);
        struct st *s=make_st(2);printf("PARSE %d %d %d\n",i,p,p?chk_gt(s,g):0);free_st(s);}
    double theta[4];srand(1);for(int i=0;i<4;i++)theta[i]=((double)rand()/RAND_MAX)*PI;
    printf("THETA");for(int i=0;i<4;i++)printf(" %.17g",theta[i]);printf("\n");
    double xs[4][2]={{0,0},{0,1},{1,0},{1,1}};
    double zero[4]={0,0,0,0};
    for(int k=0;k<4;k++) {
        struct st *s=make_st(2);
        for(int i=0;i<2;i++){struct gt g={3,i,-1,xs[k][i]*PI};app_gt(s,g,0);}
        printf("QML %d %.17g %.17g %.17g\n",k,get_o(s),fwd(xs[k],theta,2,0),fwd(xs[k],zero,2,0));
        free_st(s);
    }
    srand(1);printf("ACTUAL_TRN_BEGIN\n");trn();
    return 0;
}
