#!/usr/bin/env python3
"""Verification only: compile and exercise unchanged upstream C source.
Usage: python3 verify_baseline.py /absolute/path/to/repository
Outputs go next to this script. No upstream source is changed.
"""
import cmath
import hashlib
import json
import math
import os
import platform
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path(sys.argv[1]).resolve()

def run(args, data=None, cwd=ROOT, env=None):
    return subprocess.run(args, input=data, text=True, capture_output=True,
                          cwd=cwd, timeout=30, env=env)

def compile_c(args, log):
    p = run(args)
    (ROOT / log).write_text(p.stdout + p.stderr)
    assert p.returncode == 0, p.stderr

compile_c(['gcc', str(REPO/'a.c'), '-o', str(ROOT/'qmlc'), '-lm'], 'build.txt')
compile_c(['gcc', '-std=c11', '-Wall', '-Wextra', '-Wpedantic',
           str(REPO/'a.c'), '-o', str(ROOT/'qmlc-strict'), '-lm'], 'build-warnings.txt')

harness = r'''
#define main upstream_menu_main
#include "a.c"
#undef main
static void emit(const char *name, struct st *s) {
    printf("STATE %s", name);
    for (int i=0;i<s->sz;i++) printf(" %.17g %.17g",s->arr[i].r,s->arr[i].i);
    printf("\n"); free_st(s);
}
int main(void) {
    const double angles[]={0, PI/2, PI, -PI/3};
    for(int type=0;type<5;type++) for(int q=0;q<2;q++) {
        int count=(type<2)?1:4;
        for(int a=0;a<count;a++) {
            struct st *s=make_st(2);
            struct gt h0={1,0,-1,0},r1={3,1,-1,0.7},z0={4,0,-1,0.4};
            app_gt(s,h0,0);app_gt(s,r1,0);app_gt(s,z0,0);
            struct gt g={type,q,-1,angles[a]};app_gt(s,g,0);
            char label[80];snprintf(label,sizeof(label),"gate_%d_%d_%d",type,q,a);
            emit(label,s);
        }
    }
    for(int c=0;c<3;c++)for(int t=0;t<3;t++)if(c!=t)for(int b=0;b<8;b++) {
        struct st *s=make_st(3);s->arr[0].r=0;s->arr[b].r=1;
        struct gt g={5,t,c,0};app_gt(s,g,0);
        char label[80];snprintf(label,sizeof(label),"cx_%d_%d_%d",c,t,b);emit(label,s);
    }
    struct st *bell=make_st(2);struct gt h={1,0,-1,0},cx={5,1,0,0};
    app_gt(bell,h,0);app_gt(bell,cx,0);emit("bell",bell);
    char *bad[]={"CX 0 1 extra","X 0 extra","RY 0 nan","RY 0 inf","H 0.5","CX 0 0","BOGUS 0"};
    for(int i=0;i<7;i++){struct gt g={0};int p=get_gt(bad[i],&g);
        struct st *s=make_st(2);printf("PARSE %d %d %d\n",i,p,p?chk_gt(s,g):0);free_st(s);}
    double theta[4];srand(1);for(int i=0;i<4;i++)theta[i]=((double)rand()/RAND_MAX)*PI;
    printf("THETA");for(int i=0;i<4;i++)printf(" %.17g",theta[i]);printf("\n");
    double xs[4][2]={{0,0},{0,1},{1,0},{1,1}};
    double zero[4]={0,0,0,0};
    for(int k=0;k<4;k++) {
        struct st *s=make_st(2);
        for(int i=0;i<2;i++){struct gt g={3,i,-1,xs[k][i]*PI};app_gt(s,g,0);}
        printf("QML %d %.17g %.17g %.17g\n",k,get_o(s),fwd(xs[k],theta,2,0),fwd(xs[k],zero,2,0));
        free_st(s);
    }
    srand(1);printf("ACTUAL_TRN_BEGIN\n");trn();
    return 0;
}
'''
(ROOT/'baseline_probe.c').write_text(harness)
compile_c(['gcc','-std=c11','-Wall','-Wextra','-Wpedantic','-I',str(REPO),
           str(ROOT/'baseline_probe.c'),'-o',str(ROOT/'baseline-probe'),'-lm'], 'probe-build.txt')
p=run([str(ROOT/'baseline-probe')]);assert p.returncode==0,p.stderr
(ROOT/'probe-output.txt').write_text(p.stdout+p.stderr)

def op(v, n, kind, q=0, theta=0, control=None):
    # Independent linear operator: sum matrix elements for every input basis state.
    out=[0j]*len(v)
    c=math.cos(theta/2);s=math.sin(theta/2)
    matrices={0:[[0,1],[1,0]],1:[[2**-0.5,2**-0.5],[2**-0.5,-2**-0.5]],
              2:[[c,-1j*s],[-1j*s,c]],3:[[c,-s],[s,c]],
              4:[[cmath.exp(-1j*theta/2),0],[0,cmath.exp(1j*theta/2)]]}
    for j,amplitude in enumerate(v):
        if kind==5:
            target=j ^ (1<<q) if j & (1<<control) else j
            out[target]+=amplitude
        else:
            bit=(j>>q)&1
            for b in (0,1):
                target=(j&~(1<<q))|(b<<q)
                out[target]+=matrices[kind][b][bit]*amplitude
    return out

errors=[];count=0;angles=[0,math.pi/2,math.pi,-math.pi/3]
for line in p.stdout.splitlines():
    if not line.startswith('STATE '):continue
    tokens=line.split();label=tokens[1];z=list(map(float,tokens[2:]));actual=[complex(*z[i:i+2]) for i in range(0,len(z),2)]
    if label.startswith('gate_'):
        _,kind,q,a=label.split('_');kind,q,a=map(int,(kind,q,a))
        expected=[1+0j,0j,0j,0j]
        expected=op(expected,2,1,0);expected=op(expected,2,3,1,0.7);expected=op(expected,2,4,0,0.4)
        expected=op(expected,2,kind,q,angles[a])
    elif label.startswith('cx_'):
        _,c,t,b=label.split('_');c,t,b=map(int,(c,t,b));expected=[0j]*8
        expected[b^(1<<t) if b&(1<<c) else b]=1
    else:expected=[2**-0.5,0j,0j,2**-0.5]
    error=max(abs(a-b) for a,b in zip(actual,expected));errors.append(error);count+=1
    assert error<=1e-12,(label,error)
    assert abs(sum(abs(x)**2 for x in actual)-1)<=1e-12,label

cases={'exit':'4\n','interactive_bell':'1\n2\nH 0\nCX 0 1\nDONE\n4\n',
       'file_example':f'2\n{REPO / "circuit.txt"}\n4\n','train_first':'3\n4\n',
       'train_repeat':'3\n4\n','train_twice':'3\n3\n4\n'}
legacy='2junk\nX 0 extra\nCX 0 2\nBOGUS 0\nH 1\n'
(ROOT/'legacy-invalid.circuit').write_text(legacy)
cases['legacy_invalid']=f'2\n{ROOT / "legacy-invalid.circuit"}\n4\n'
fixture='4\nRY 0 0.3\nRY 1 -0.2\nRY 2 0.5\nRY 3 0.7\nCX 0 1\nCX 0 3\nCX 2 3\nRZ 3 0.4\n'
(ROOT/'pqc4.circuit').write_text(fixture)
cases['pqc4_ideal']=f'2\n{ROOT / "pqc4.circuit"}\n4\n'
results={}
for name,data in cases.items():
    (ROOT/(name+'.stdin')).write_text(data)
    result=run([str(ROOT/'qmlc')],data)
    assert result.returncode==0,(name,result.stderr)
    (ROOT/(name+'.stdout')).write_text(result.stdout)
    results[name]={'returncode':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout.encode()).hexdigest()}
assert (ROOT/'train_first.stdout').read_bytes()==(ROOT/'train_repeat.stdout').read_bytes()
assert 'Gates applied: 4' in (ROOT/'file_example.stdout').read_text()
assert 'Gates applied: 2' in (ROOT/'interactive_bell.stdout').read_text()
assert 'Gates applied: 2' in (ROOT/'legacy_invalid.stdout').read_text()
assert 'Gates applied: 8' in (ROOT/'pqc4_ideal.stdout').read_text()

compile_c(['gcc','-std=c11','-Wall','-Wextra','-Wpedantic',
           '-fsanitize=address,undefined','-fno-omit-frame-pointer','-g','-I',str(REPO),
           str(ROOT/'baseline_probe.c'),'-o',str(ROOT/'baseline-probe-sanitized'),'-lm'], 'sanitizer-build.txt')
# This hosted runtime restricts LeakSanitizer's process inspection. Keep address
# and undefined-behavior checks enabled, and report leak checking as unavailable.
san=run([str(ROOT/'baseline-probe-sanitized')],env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'})
(ROOT/'sanitizer-no-leaks.stdout').write_text(san.stdout)
(ROOT/'sanitizer-no-leaks.stderr').write_text(san.stderr)
assert san.returncode==0 and not san.stderr,(san.returncode,san.stderr)

qml=[]
for line in p.stdout.splitlines():
    if line.startswith('QML '):
        a=line.split();qml.append({'input_index':int(a[1]),'encoding_only':float(a[2]),'initial':float(a[3]),'zero_parameter_full_pqc':float(a[4])})
y=[0,1,1,0]
theta=list(map(float,re.search(r'^THETA (.+)$',p.stdout,re.M).group(1).split()))
forward_errors=[]
for k,row in enumerate(qml):
    features=[(k>>1)&1,k&1]
    v=[1+0j,0j,0j,0j]
    for q in range(2):v=op(v,2,3,q,features[q]*math.pi)
    for q in range(2):v=op(v,2,3,q,theta[q])
    v=op(v,2,5,1,control=0)
    for q in range(2):v=op(v,2,3,q,theta[2+q])
    expected=abs(v[1])**2+abs(v[2])**2
    forward_errors.append(abs(expected-row['initial']))
assert max(forward_errors)<=1e-12
preds=[float(x) for x in re.findall(r'-> Pred: ([0-9.]+)',(ROOT/'train_first.stdout').read_text())]
def metrics(values):return {'mse':sum((a-b)**2 for a,b in zip(values,y))/4,'accuracy':sum((a>=.5)==bool(b) for a,b in zip(values,y))/4}
report={'repository_commit':run(['git','rev-parse','HEAD'],cwd=REPO).stdout.strip(),
        'source_sha256':hashlib.sha256((REPO/'a.c').read_bytes()).hexdigest(),
        'environment':{'platform':platform.platform(),'gcc':run(['gcc','--version']).stdout.splitlines()[0],
                       'glibc':run(['ldd','--version']).stdout.splitlines()[0],
                       'python':sys.version.split()[0]},
        'strict_build_warnings':(ROOT/'build-warnings.txt').read_text(),
        'sanitizer_address_undefined_returncode':san.returncode,'leak_checking':'UNAVAILABLE_IN_HOSTED_RUNTIME',
        'statevector_cases':count,'max_complex_amplitude_absolute_error':max(errors),
        'initial_forward_reference_cases':len(forward_errors),'max_initial_forward_probability_error':max(forward_errors),
        'initial_theta_seed1':theta,
        'qml_rows':qml,'encoding_only_metrics':metrics([q['encoding_only'] for q in qml]),
        'initial_metrics':metrics([q['initial'] for q in qml]),
        'trained_predictions_rounded_4dp':preds,'trained_metrics_from_rounded_predictions':metrics(preds),
        'same_environment_fresh_process_training_identical':True,
        'cli_cases':results,'source_worktree_status':run(['git','status','--short'],cwd=REPO).stdout}
(ROOT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
